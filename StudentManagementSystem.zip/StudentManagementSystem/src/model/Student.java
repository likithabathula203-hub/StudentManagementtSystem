
package model;

public class Student {

    private int studentId;
    private String name;
    private String course;
    private String email;
    private double marks;

    public Student(int studentId, String name, String course, String email, double marks) {

        this.studentId = studentId;
        this.name = name;
        this.course = course;
        this.email = email;
        this.marks = marks;
    }

    public int getStudentId() {
        return studentId;
    }

    public String getName() {
        return name;
    }

    public String getCourse() {
        return course;
    }

    public String getEmail() {
        return email;
    }

    public double getMarks() {
        return marks;
    }
}