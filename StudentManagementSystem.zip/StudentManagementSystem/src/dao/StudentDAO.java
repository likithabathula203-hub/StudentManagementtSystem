
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import model.Student;
import util.DBConnection;

public class StudentDAO {

    // Add Student
    public void addStudent(Student student) {

        try {

            Connection con = DBConnection.getConnection();

            String query = "INSERT INTO students VALUES(?,?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, student.getStudentId());
            ps.setString(2, student.getName());
            ps.setString(3, student.getCourse());
            ps.setString(4, student.getEmail());
            ps.setDouble(5, student.getMarks());

            ps.executeUpdate();

            System.out.println("Student Added Successfully");

        } catch (Exception e) {

            System.out.println(e);
        }
    }

    // View Students
    public void viewStudents() {

        try {

            Connection con = DBConnection.getConnection();

            String query = "SELECT * FROM students";

            PreparedStatement ps = con.prepareStatement(query);

            ResultSet rs = ps.executeQuery();

            while(rs.next()) {

                System.out.println("ID : " + rs.getInt("student_id"));
                System.out.println("Name : " + rs.getString("name"));
                System.out.println("Course : " + rs.getString("course"));
                System.out.println("Email : " + rs.getString("email"));
                System.out.println("Marks : " + rs.getDouble("marks"));

                System.out.println("-------------------");
            }

        } catch (Exception e) {

            System.out.println(e);
        }
    }
}